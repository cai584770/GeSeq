package org.cai.geseq;

/**
 * @author cai584770
 * @date 2024/10/16 19:42
 * @Version
 */
public enum BioSequenceEnum {
    DNA, RNA, PROTEIN;
}
