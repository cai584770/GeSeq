package org.cai.geseq;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Map;

/**
 * @author cai584770
 * @date 2024/10/16 19:34
 * @Version
 */
public class GeSeq {

    private byte[] sequence;
    private List<int[]> lowercase;
    private List<int[]> nBase;
    private List<Object[]> otherBASE;
    private long sequenceLength;
    private long nucleotidesLength;

    public GeSeq(byte[] sequence, List<int[]> lowercase, List<int[]> nBase, List<Object[]> otherBASE, long sequenceLength, long nucleotidesLength) {
        this.sequence = sequence;
        this.lowercase = lowercase;
        this.nBase = nBase;
        this.otherBASE = otherBASE;
        this.sequenceLength = sequenceLength;
        this.nucleotidesLength = nucleotidesLength;
    }

    public byte[] getbbm() {
        return sequence;
    }

    public Map<String, Object> toNeo4jMap() {
        List<Map<String, Integer>> lowercaseMaps = new ArrayList<>();
        for (int[] pair : lowercase) {
            lowercaseMaps.add(Map.of("start", pair[0], "length", pair[1]));
        }

        List<Map<String, Integer>> nBaseMaps = new ArrayList<>();
        for (int[] pair : nBase) {
            nBaseMaps.add(Map.of("start", pair[0], "length", pair[1]));
        }

        List<Map<String, Object>> otherBaseMaps = new ArrayList<>();
        for (Object[] pair : otherBASE) {
            otherBaseMaps.add(Map.of("key", pair[0], "value", pair[1]));
        }

        return Map.of(
                "sequence", Base64.getEncoder().encodeToString(sequence),
                "lowercase", lowercaseMaps,
                "nBase", nBaseMaps,
                "otherBASE", otherBaseMaps,
                "sequenceLength", sequenceLength,
                "nucleotidesLength", nucleotidesLength
        );
    }

    public byte[] toByteArray() {
        int bbmSize = 4 + sequence.length;
        int lowercaseSize = 4 + lowercase.size() * (4 + 4);
        int nBaseSize = 4 + nBase.size() * (4 + 4);
        int otherBASESize = 4;
        for (Object[] pair : otherBASE) {
            otherBASESize += 4 + 4 + ((String) pair[1]).getBytes().length;
        }
        int lengthSize = 8 + 8;

        ByteBuffer buffer = ByteBuffer.allocate(bbmSize + lowercaseSize + nBaseSize + otherBASESize + lengthSize);

        buffer.putInt(sequence.length);
        buffer.put(sequence);

        buffer.putInt(lowercase.size());
        for (int[] pair : lowercase) {
            buffer.putInt(pair[0]);
            buffer.putInt(pair[1]);
        }

        buffer.putInt(nBase.size());
        for (int[] pair : nBase) {
            buffer.putInt(pair[0]);
            buffer.putInt(pair[1]);
        }

        buffer.putInt(otherBASE.size());
        for (Object[] pair : otherBASE) {
            buffer.putInt((int) pair[0]);
            byte[] valueBytes = ((String) pair[1]).getBytes();
            buffer.putInt(valueBytes.length);
            buffer.put(valueBytes);
        }

        buffer.putLong(sequenceLength);
        buffer.putLong(nucleotidesLength);

        return buffer.array();
    }

    public static GeSeq fromSequence(String data) {
        List<int[]> lowerCaseList = new ArrayList<>();
        List<int[]> nCaseList = new ArrayList<>();
        List<Object[]> otherCaseList = new ArrayList<>();
        byte[] sequence2bit = new byte[0];
        return new GeSeq(sequence2bit, lowerCaseList, nCaseList, otherCaseList, data.length(), 0);
    }

    public static byte[] extractBbm(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        int bbmLength = buffer.getInt();
        byte[] bbm = new byte[bbmLength];
        buffer.get(bbm);
        return bbm;
    }

    public static Map<String, Object> convertGeSeqToNeo4jFormat(GeSeq geSeq) {
        List<Map<String, Integer>> lowercaseMaps = new ArrayList<>();
        for (int[] pair : geSeq.lowercase) {
            lowercaseMaps.add(Map.of("first", pair[0], "second", pair[1]));
        }

        List<Map<String, Integer>> nBaseMaps = new ArrayList<>();
        for (int[] pair : geSeq.nBase) {
            nBaseMaps.add(Map.of("first", pair[0], "second", pair[1]));
        }

        List<Map<String, Object>> otherBaseMaps = new ArrayList<>();
        for (Object[] pair : geSeq.otherBASE) {
            otherBaseMaps.add(Map.of("key", pair[0], "value", pair[1]));
        }

        return Map.of(
                "sequence", Base64.getEncoder().encodeToString(geSeq.sequence),
                "lowercase", lowercaseMaps,
                "nBase", nBaseMaps,
                "otherBASE", otherBaseMaps,
                "sequenceLength", geSeq.sequenceLength,
                "nucleotidesLength", geSeq.nucleotidesLength
        );
    }

    public static GeSeq fromByteArray(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.wrap(bytes);

        int bbmLength = buffer.getInt();
        byte[] bbm = new byte[bbmLength];
        buffer.get(bbm);

        int lowercaseSize = buffer.getInt();
        List<int[]> lowercase = new ArrayList<>();
        for (int i = 0; i < lowercaseSize; i++) {
            int start = buffer.getInt();
            int length = buffer.getInt();
            lowercase.add(new int[]{start, length});
        }

        int nBaseSize = buffer.getInt();
        List<int[]> nBase = new ArrayList<>();
        for (int i = 0; i < nBaseSize; i++) {
            int start = buffer.getInt();
            int length = buffer.getInt();
            nBase.add(new int[]{start, length});
        }

        int otherBASESize = buffer.getInt();
        List<Object[]> otherBASE = new ArrayList<>();
        for (int i = 0; i < otherBASESize; i++) {
            int start = buffer.getInt();
            int valueLength = buffer.getInt();
            byte[] valueBytes = new byte[valueLength];
            buffer.get(valueBytes);
            String value = new String(valueBytes);
            otherBASE.add(new Object[]{start, value});
        }

        long sequenceLength = buffer.getLong();
        long nucleotidesLength = buffer.getLong();

        return new GeSeq(bbm, lowercase, nBase, otherBASE, sequenceLength, nucleotidesLength);
    }

}
