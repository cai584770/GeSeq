package org.cai.geseq;

import org.cai.file.processor.FileNormalize;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author cai584770
 * @date 2024/10/16 19:43
 * @Version
 */
public class BBM {

    public static void bbmT(String data) {
        String sequence = FileNormalize.remove(data);
        int sequenceLength = sequence.length();

//        初始化参数
        boolean caseFlag = false; // 大小写标志


        for (char c : sequence.toCharArray()) {


//            1.判断大小写
//            小写转大写，看caseFlag是否
            if (Character.isLowerCase(c)) {

            } else {

            }


//            2.判断是否是N


//            3.判断是否是简并碱基




        }

    }

    public static Map<String, List<Object>> bbm(String data) {
        String sequence = FileNormalize.remove(data);
        int sequenceLength = sequence.length();

        Pair<String, List<int[]>> lowerCaseResult = findConsecutiveLowerCasePositions(sequence);
        Pair<String, List<int[]>> nCaseResult = removeAndRecordN(lowerCaseResult.getFirst());
        Pair<String, List<Object[]>> otherCaseResult = removeAndRecord(nCaseResult.getFirst());

        int agctSequenceLength = otherCaseResult.getFirst().length();
        List<int[]> lengthList = List.of(new int[]{sequenceLength, agctSequenceLength});

        byte[] sequence2bit = convertToBinaryArray(otherCaseResult.getFirst());

        Map<String, List<Object>> supplementaryInformation = Map.ofEntries(
                Map.entry("LowerCasePosition", new ArrayList<>(lowerCaseResult.getSecond())),
                Map.entry("NCasePosition", new ArrayList<>(nCaseResult.getSecond())),
                Map.entry("OtherCaseList", new ArrayList<>(otherCaseResult.getSecond())),
                Map.entry("Length", new ArrayList<>(lengthList))
        );

        return supplementaryInformation;
    }

    public static byte[] convertToBinaryArray(String s) {
        Map<Character, String> conversionMap = Map.of(
                'A', "00",
                'G', "10",
                'C', "01",
                'T', "11"
        );

        StringBuilder binaryStringBuilder = new StringBuilder();
        for (char c : s.toCharArray()) {
            String binaryValue = conversionMap.getOrDefault(c, "");
            binaryStringBuilder.append(binaryValue);
        }

        String binaryString = binaryStringBuilder.toString();
        int byteLength = binaryString.length() / 8 + (binaryString.length() % 8 == 0? 0 : 1);
        byte[] binaryArray = new byte[byteLength];

        for (int i = 0; i < binaryArray.length; i++) {
            int byteValue = 0;
            for (int j = 0; j < 8; j++) {
                int charIndex = i * 8 + j;
                if (charIndex < binaryString.length() && binaryString.charAt(charIndex) == '1') {
                    byteValue |= (1 << (7 - j));
                }
            }
            binaryArray[i] = (byte) byteValue;
        }

        return binaryArray;
    }

    public static Pair<String, List<int[]>> removeAndRecordN(String s) {
        List<int[]> positions = new ArrayList<>();
        StringBuilder result = new StringBuilder();

        int start = 0;
        int end = 0;
        int prePosition = 0;

        int length = 0;
        while (end < s.length()) {
            if (s.charAt(end) == 'N') {
                start = end;
                while (end < s.length() && s.charAt(end) == 'N') {
                    end++;
                }
                if (end < s.length()) {
                    result.append(s.charAt(end));
                }
                positions.add(new int[]{start - prePosition - length, end - start});
                prePosition = start;
                length = end - start;
            } else {
                result.append(s.charAt(end));
            }
            end++;
        }

        return new Pair<>(result.toString(), positions);
    }

    public static Pair<String, List<Object[]>> removeAndRecord(String s) {
        StringBuilder result = new StringBuilder(s);
        List<Object[]> positions = new ArrayList<>();
        int pos = 0;

        int index = 0;
        while (index < result.length()) {
            char currentChar = result.charAt(index);
            if (!List.of('A', 'G', 'C', 'T').contains(currentChar)) {
                int start = index;
                StringBuilder subString = new StringBuilder(currentChar + "");
                result.deleteCharAt(index);
                while (index < result.length() &&!List.of('A', 'G', 'C', 'T').contains(result.charAt(index))) {
                    subString.append(result.charAt(index));
                    result.deleteCharAt(index);
                }
                positions.add(new Object[]{start - pos, subString.toString()});
                pos = start;
            } else {
                index++;
            }
        }

        return new Pair<>(result.toString(), positions);
    }

    public static Pair<String, List<int[]>> findConsecutiveLowerCasePositions(String s) {
        List<int[]> result = new ArrayList<>();
        StringBuilder sequenceBuilder = new StringBuilder();
        int startIndex = -1;
        int length = 0;
        int realStartPos = 0;

        for (int index = 0; index < s.length(); index++) {
            char c = s.charAt(index);
            if (Character.isLowerCase(c)) {
                sequenceBuilder.append(Character.toUpperCase(c));
                if (startIndex == -1) {
                    startIndex = index;
                }
                length++;
            } else {
                sequenceBuilder.append(c);
                if (startIndex!= -1) {
                    result.add(new int[]{startIndex - realStartPos, length});
                    realStartPos = startIndex + length;
                    startIndex = -1;
                    length = 0;
                }
            }
        }

        if (startIndex!= -1) {
            result.add(new int[]{startIndex - realStartPos, length});
        }

        return new Pair<>(sequenceBuilder.toString(), result);
    }

    static class Pair<K, V> {
        private K first;
        private V second;

        public Pair(K first, V second) {
            this.first = first;
            this.second = second;
        }

        public K getFirst() {
            return first;
        }

        public V getSecond() {
            return second;
        }
    }

}
